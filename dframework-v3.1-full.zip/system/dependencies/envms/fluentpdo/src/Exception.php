<?php

namespace Envms\FluentPDO;

/**
 * Class Exception
 */
class Exception extends \Exception
{

}
