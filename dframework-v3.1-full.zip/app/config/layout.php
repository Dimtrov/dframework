<?php


$layout['default'] = [
    // fichiers de style des plugins
    'lib_styles' => [
    ],
    // fichiers de script des plugins
    'lib_scripts' => [
    ],
    // fichiers de style de l'application
    'styles' => [
    ],
    // fichiers de script de l'application
    'scripts' => [
    ],
];



/**
 * DON'T TOUCH THIS LINE. IT'S USING BY CONFIG CLASS
 */
return compact('layout');